using Microsoft.AspNetCore.Mvc;
using proyectoApiWeb.Application.Services;
using proyectoApiWeb.Domain.Models;

namespace proyectoApiWeb.Api.Controllers;
// No se nos puede olvidar estas etiquetas.
//[controller] le daría el nombre principal de product, el controller lo omite
[ApiController]
[Route("api/[controller]")]

// para mvc es solo controller, para este webapi cambiamos a ControllerBase
public class ProductController : ControllerBase
{
    private readonly ProductService _productService;

    // Constructor:
    public ProductController(ProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(_productService.GetAll());
    }


    [HttpPost]
    public IActionResult Add(Product product)
    {
        var create = _productService.Add(product);
        return Ok(create);
    }
    
    
    
    
}