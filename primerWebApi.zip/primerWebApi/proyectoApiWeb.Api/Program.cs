using proyectoApiWeb.Application.Services;
using proyectoApiWeb.Domain.Models;

var builder = WebApplication.CreateBuilder(args);

// ------------------------------------------
//Inyeccion de dependencias
builder.Services.AddSingleton<ProductService>();
// ------------------------------------------


// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

// ------------------------------------------------
// PRODUCTS:

// POST - CREATE:
app.MapPost("/addProduct", (Product product, ProductService productService) =>
{
    var create = productService.Add(product);
    return Results.Created($"api/product/{product.Id}", create);
});


// GET - READ:
app.MapGet("/getProduct", (ProductService productService) =>
{
    return Results.Ok(productService.GetAll());
});


// PUT - UPDATE:
app.MapPut("/updateProduct/{id}", (int id, Product input, ProductService productService) =>
{
    var existingProduct = productService.GetById(id);
    if (existingProduct is null)
        return Results.NotFound($"Producto con ID {id} no encontrado.");

    input.Id = id; // Asegurar que el ID se mantenga correcto
    var updated = productService.Update(input);
    return Results.Ok(updated);
});


// DELETE:
app.MapDelete("/deleteProduct/{id}", (int id, ProductService productService) =>
{
    var deleted = productService.Delete(id);
    if (!deleted)
        return Results.NotFound($"Producto con ID {id} no encontrado.");

    return Results.NoContent();
});

// ------------------------------------
// CUSTOMERS:

// POST:


// GET:


// PUT:


// DELETE:


// ------------------------------------------------

app.MapGet("/weatherforecast", () =>
{
    var forecast =  Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
    return forecast;
})
.WithName("GetWeatherForecast")
.WithOpenApi();

app.Run();

record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
