using proyectoApiWeb.Domain.Models;

namespace proyectoApiWeb.Application.Services;

public class ProductService
{
    private readonly List<Product> _products = new ();
    private int _nextId = 1;
    
    //ENDPOINTS
    
    // POST - CREATE:
    public Product Add(Product product)
    {
        product.Id = _nextId++;
        _products.Add(product);
        return product;
    }
    
    
    // GET - READ:
    public IEnumerable<Product> GetAll()
    {
        return _products;
    }


    
    // Obtener producto por ID
    public Product? GetById(int id)
    {
        return _products.FirstOrDefault(p => p.Id == id);
    }
    
    
    // PUT - UPDATE:
    public Product? Update(Product updatedProduct)
    {
        var existing = GetById(updatedProduct.Id);
        if (existing is null)
            return null;

        existing.Name = updatedProduct.Name;
        existing.Price = updatedProduct.Price;

        return existing;
    }
    
    // DELETE:
    public bool Delete(int id)
    {
        var product = GetById(id);
        if (product is null)
            return false;

        _products.Remove(product);
        return true;
    }
}