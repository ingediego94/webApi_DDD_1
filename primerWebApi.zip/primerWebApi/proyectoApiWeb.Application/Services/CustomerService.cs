using proyectoApiWeb.Domain.Models;

namespace proyectoApiWeb.Application.Services;

public class CustomerService
{
    private readonly List<Customer> _customers = new();
    private int _nextId = 1;
    
    // Create
    public Customer Adding(Customer customer)
    {
        customer.Id = _nextId++;
        _customers.Add(customer);
        return customer;
    }
    
    
    // Read
    public IEnumerable<Customer> Read()
    {
        return _customers;
    }
    
    // Obtener producto por ID
    public Customer? GetById(int id)
    {
        return _customers.FirstOrDefault(p => p.Id == id);
    }
    
    // Delete
    public bool Delete(int id)
    {
        // We can use this one, but the second works in the same way.
        // var customer = GetById(id);
        var customer = _customers.FirstOrDefault(c => c.Id == id);
        if (customer is null)
            return false;

        _customers.Remove(customer);
        return true;
    }

    
    // PUT - UPDATE
    public Customer? Update(Customer updatedCustomer)
    {
        // this linq query works only if you put: (int id) in the parameters
        //var existing = _customers.FirstOrDefault(c => c.Id == id);
        var existing = GetById(updatedCustomer.Id);
        
        if (existing is null)
            return null;

        existing.Name = updatedCustomer.Name;
        existing.Email = updatedCustomer.Email;
        existing.Phone = updatedCustomer.Phone;

        return existing;
    }
}